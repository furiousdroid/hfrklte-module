ui_print "Setting file permissions..."
set_perm $MODPATH/system/vendor/lib/hw/camera.msm8974.so 0 0 0644 u:object_r:vendor_file:s0
set_perm $MODPATH/system/vendor/etc/media_profiles_V1_0.xml 0 0 0644 u:object_r:vendor_configs_file:s0
