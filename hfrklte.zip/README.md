## High-Framerate for Samsung GALAXY S5 (klte)
### For LineageOS18.1

